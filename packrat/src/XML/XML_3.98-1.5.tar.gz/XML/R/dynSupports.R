supportsExpat <-
function()
{
  is.loaded("RS_XML_initParser")
}

supportsLibxml <-
function()
{
  is.loaded("RS_XML_piHandler")
}
