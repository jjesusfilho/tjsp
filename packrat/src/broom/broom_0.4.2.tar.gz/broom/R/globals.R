globalVariables(c(".", "estimate", "std.error", "statistic", "term", "p.value",
                "effect", "se", "objs", "comp", "N", "lambda", "GCV", "obs",
                ".id", "level", "group1", "group2", "series", "value",
                "index", "df.residual", "stratum", "conf.low", "conf.high",
                "step", "fit", "type", "expCIWidth", "column1", "column2",
                "PC", "loading", "column", "comparison", "item1", "item2",
                "Method", "Intercept", "Slope", "method", "key", "Var1",
                "Var2", "variable"))
